package course;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class requirements extends JFrame {
    private JPanel requirementspanel;
    private JCheckBox BIRTHCERTIFICATECheckBox;
    private JCheckBox GOODMORALCheckBox;
    private JCheckBox FORM137CheckBox;
    private JButton UPLOADFILEButton;
    private JButton CANCELButton;
    private JFrame frame;

    public requirements() {
        frame = new JFrame("requirements");
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(1000, 550));
        frame.setResizable(false);

//now add the panel
        frame.add(requirementspanel);

        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        UPLOADFILEButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(UPLOADFILEButton,JCheckBox.getDefaultLocale()+" ,Successfully Enrolled");
            }
        });
        CANCELButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
    }

    public static void main(String[] args) {
        requirements requirements = new requirements();
        requirements.setContentPane(requirements.requirementspanel);
        requirements.setTitle("Successfully enrolled");
        requirements.setSize(1000, 550);
        requirements.setVisible(true);
        requirements.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
