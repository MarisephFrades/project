package course;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class course extends Frame {
    private JPanel CoursePanel;
    private JPanel cboxCourse;
    private JComboBox comboBox1;
    private JButton NEXTButton;
    private JButton CANCELButton;
    private JLabel courseselection;
    private JFrame jFrame;

    public course() {
        JFrame frame = new JFrame("Course");
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(1000, 550));
        frame.setResizable(false);

//now add the panel
        frame.add(CoursePanel);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        NEXTButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                requirements requirementsObject = new requirements();
            }
        });
        CANCELButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
    }
}