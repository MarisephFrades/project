package Registration;

public class MAIN {
    public static void main(String [] args) {
        //create the object of registration to see its working or Not
        new registration();



    }

}
