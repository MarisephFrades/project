package Registration;

import course.course;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;

public class registration extends JFrame {
    private JTextField tfFirstName;
    private JTextField tfAddress;
    private JTextField tfStatus;
    private JTextField tfNationality;
    private JTextField tfEmail;
    private JTextField tfContactNumber;
    private JTextField tfMiddleName;
    private JTextField tfExtension;
    private JTextField tfLastName;
    private JTextField tfBirthday;
    private JTextField tfGender;
    private JTextField tfLrn;
    private JButton SUBMITButton;
    private JButton CANCELButton;
    private JPanel registrationPanel;
    private JFrame frame;

    public registration() {
        frame = new JFrame("Registration Form");
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(1200, 550));
        frame.setResizable(false);

//now add the panel
        frame.add(registrationPanel);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);


        SUBMITButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                course courseObject = new course();
            }
        });
        CANCELButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
    }
}
